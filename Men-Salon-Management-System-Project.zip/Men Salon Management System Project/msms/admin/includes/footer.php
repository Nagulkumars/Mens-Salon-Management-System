<!--footer-->
    <div class="footer">
       <p>&copy; 2021 Men's Salon Management System Admin Panel.</p>
    </div>
        <!--//footer-->